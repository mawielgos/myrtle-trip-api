package com.myrtletrip.scoreentry.dto;

public class RoundScorecardResponse {

    private Long scorecardId;
    private Long playerId;
    private String playerName;

    private Integer playingHandicap;
    private Integer grossScore;
    private Integer netScore;

    public Long getScorecardId() { return scorecardId; }
    public void setScorecardId(Long scorecardId) { this.scorecardId = scorecardId; }

    public Long getPlayerId() { return playerId; }
    public void setPlayerId(Long playerId) { this.playerId = playerId; }

    public String getPlayerName() { return playerName; }
    public void setPlayerName(String playerName) { this.playerName = playerName; }

    public Integer getPlayingHandicap() { return playingHandicap; }
    public void setPlayingHandicap(Integer playingHandicap) { this.playingHandicap = playingHandicap; }

    public Integer getGrossScore() { return grossScore; }
    public void setGrossScore(Integer grossScore) { this.grossScore = grossScore; }

    public Integer getNetScore() { return netScore; }
    public void setNetScore(Integer netScore) { this.netScore = netScore; }
}