package com.myrtletrip.scoreentry.controller;

import com.myrtletrip.scoreentry.dto.RoundScorecardResponse;
import com.myrtletrip.scoreentry.service.ScoringService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/scorecards")
public class ScoreEntryController {

    private final ScoringService scoringService;

    public ScoreEntryController(ScoringService scoringService) {
        this.scoringService = scoringService;
    }

    @PutMapping("/{scorecardId}/holes/{holeNumber}")
    public void updateHoleScore(
            @PathVariable Long scorecardId,
            @PathVariable int holeNumber,
            @RequestBody HoleRequest request) {

        scoringService.updateHoleScore(scorecardId, holeNumber, request.strokes());
    }
    
    @PostMapping("/{scorecardId}/recalculate")
    public void recalculateScorecard(@PathVariable Long scorecardId) {
        scoringService.recalculate(scorecardId);
    }
    public record HoleRequest(int strokes) {}

    @GetMapping("/rounds/{roundId}/scorecards")
    public List<RoundScorecardResponse> getRoundScorecards(@PathVariable Long roundId) {
        return scoringService.getRoundScorecards(roundId);
    }
}