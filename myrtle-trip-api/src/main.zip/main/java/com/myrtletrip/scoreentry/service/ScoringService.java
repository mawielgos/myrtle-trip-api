package com.myrtletrip.scoreentry.service;

import com.myrtletrip.course.service.CourseService;
import com.myrtletrip.scoreentry.dto.HoleScoreResponse;
import com.myrtletrip.scoreentry.dto.RoundScorecardResponse;
import com.myrtletrip.scoreentry.dto.ScorecardResponse;
import com.myrtletrip.scoreentry.entity.HoleScore;
import com.myrtletrip.scoreentry.entity.Scorecard;
import com.myrtletrip.scoreentry.repository.HoleScoreRepository;
import com.myrtletrip.scoreentry.repository.ScorecardRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class ScoringService {

    private final HoleScoreRepository holeRepo;
    private final ScorecardRepository scorecardRepo;
    private final CourseService courseService;

    public ScoringService(HoleScoreRepository holeRepo,
                          ScorecardRepository scorecardRepo,
                          CourseService courseService) {
        this.holeRepo = holeRepo;
        this.scorecardRepo = scorecardRepo;
        this.courseService = courseService;
    }

    public void updateHoleScore(Long scorecardId, int holeNumber, int strokes) {

        HoleScore hole = holeRepo
                .findByScorecard_IdAndHoleNumber(scorecardId, holeNumber)
                .orElseGet(() -> {
                    HoleScore newHole = new HoleScore();
                    newHole.setHoleNumber(holeNumber);
                    newHole.setScorecard(scorecardRepo.getReferenceById(scorecardId));
                    return newHole;
                });

        hole.setStrokes(strokes);
        holeRepo.save(hole);

        recalculateScorecard(scorecardId);
    }

    public void recalculate(Long scorecardId) {
        recalculateScorecard(scorecardId);
    }

    public ScorecardResponse getScorecard(Long scorecardId) {
        Scorecard scorecard = scorecardRepo.findById(scorecardId).orElseThrow();

        List<HoleScore> holes = holeRepo.findByScorecard_IdOrderByHoleNumberAsc(scorecardId);

        ScorecardResponse response = new ScorecardResponse();
        response.setScorecardId(scorecard.getId());
        response.setRoundId(scorecard.getRound().getId());
        response.setPlayerId(scorecard.getPlayer().getId());
        response.setPlayingHandicap(scorecard.getPlayingHandicap());
        response.setGrossScore(scorecard.getGrossScore());
        response.setNetScore(scorecard.getNetScore());

        List<HoleScoreResponse> holeResponses = holes.stream().map(h -> {
            HoleScoreResponse dto = new HoleScoreResponse();
            dto.setHoleNumber(h.getHoleNumber());
            dto.setStrokes(h.getStrokes());
            dto.setNetStrokes(h.getNetStrokes());
            dto.setAdjustedStrokes(h.getAdjustedStrokes());
            return dto;
        }).toList();

        response.setHoles(holeResponses);
        return response;
    }

    private void recalculateScorecard(Long scorecardId) {

        Scorecard sc = scorecardRepo.findById(scorecardId).orElseThrow();

        List<HoleScore> holes =
                holeRepo.findByScorecard_IdOrderByHoleNumberAsc(scorecardId);

        int gross = 0;
        int totalNet = 0;

        Long courseTeeId = sc.getRound().getCourseTee().getId();
        int playerHandicap = sc.getPlayingHandicap() == null ? 0 : sc.getPlayingHandicap();

        for (HoleScore h : holes) {
            int strokes = h.getStrokes() == null ? 0 : h.getStrokes();
            gross += strokes;

            int holeHcp = courseService.getHoleHandicap(courseTeeId, h.getHoleNumber());
            int handicapStrokes = getStrokesForHole(playerHandicap, holeHcp);

            int netStrokes = strokes - handicapStrokes;
            totalNet += netStrokes;

            h.setNetStrokes(netStrokes);
            h.setAdjustedStrokes(strokes);

            holeRepo.save(h);
        }

        sc.setGrossScore(gross);
        sc.setNetScore(totalNet);

        scorecardRepo.save(sc);
    }

    private int getStrokesForHole(int playerHandicap, int holeHandicap) {
        if (playerHandicap <= 0) {
            return 0;
        }

        int base = playerHandicap / 18;
        int remainder = playerHandicap % 18;
        int extra = holeHandicap <= remainder ? 1 : 0;

        return base + extra;
    }
    public List<RoundScorecardResponse> getRoundScorecards(Long roundId) {

        List<Scorecard> scorecards = scorecardRepo.findByRound_Id(roundId);

        return scorecards.stream().map(sc -> {
            RoundScorecardResponse dto = new RoundScorecardResponse();

            dto.setScorecardId(sc.getId());
            dto.setPlayerId(sc.getPlayer().getId());
            dto.setPlayerName(sc.getPlayer().getDisplayName());

            dto.setPlayingHandicap(sc.getPlayingHandicap());
            dto.setGrossScore(sc.getGrossScore());
            dto.setNetScore(sc.getNetScore());

            return dto;
        })
        // leaderboard sort (net score ascending)
        .sorted((a, b) -> Integer.compare(
                a.getNetScore() == null ? 999 : a.getNetScore(),
                b.getNetScore() == null ? 999 : b.getNetScore()
        ))
        .toList();
    }
}