package com.myrtletrip.course.repository;

import com.myrtletrip.course.entity.CourseHole;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CourseHoleRepository extends JpaRepository<CourseHole, Long> {

    List<CourseHole> findByCourseTeeIdOrderByHoleNumberAsc(Long courseTeeId);

    Optional<CourseHole> findByCourseTeeIdAndHoleNumber(Long courseTeeId, Integer holeNumber);
}