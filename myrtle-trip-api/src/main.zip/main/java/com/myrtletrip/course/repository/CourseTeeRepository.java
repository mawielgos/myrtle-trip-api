package com.myrtletrip.course.repository;

import com.myrtletrip.course.entity.CourseTee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseTeeRepository extends JpaRepository<CourseTee, Long> {
}