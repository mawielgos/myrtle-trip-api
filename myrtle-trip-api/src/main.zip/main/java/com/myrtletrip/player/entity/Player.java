package com.myrtletrip.player.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "player")
public class Player {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "display_name")
    private String displayName;

    @Column(name = "ghin_number")
    private String ghinNumber;

    private boolean active;

    // getters/setters (or Lombok if enabled)
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getDisplayName() { return displayName; }
    public void setDisplayName(String displayName) { this.displayName = displayName; }

    public String getGhinNumber() { return ghinNumber; }
    public void setGhinNumber(String ghinNumber) { this.ghinNumber = ghinNumber; }

    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
}