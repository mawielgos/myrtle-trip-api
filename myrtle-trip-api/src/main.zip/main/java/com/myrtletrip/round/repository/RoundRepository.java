package com.myrtletrip.round.repository;

import com.myrtletrip.round.entity.Round;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RoundRepository extends JpaRepository<Round, Long> {

    List<Round> findByTrip_IdOrderByRoundNumber(Long tripId);
}