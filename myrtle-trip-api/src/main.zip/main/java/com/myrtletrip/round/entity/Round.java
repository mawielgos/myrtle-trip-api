package com.myrtletrip.round.entity;

import com.myrtletrip.course.entity.CourseTee;
import com.myrtletrip.trip.entity.Trip;
import jakarta.persistence.*;

@Entity
@Table(name = "round")
public class Round {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "trip_id", nullable = false)
    private Trip trip;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "course_tee_id", nullable = false)
    private CourseTee courseTee;

    @Column(name = "round_number", nullable = false)
    private Integer roundNumber;

    @Column(name = "display_name", nullable = false)
    private String displayName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Trip getTrip() {
        return trip;
    }

    public void setTrip(Trip trip) {
        this.trip = trip;
    }

    public CourseTee getCourseTee() {
        return courseTee;
    }

    public void setCourseTee(CourseTee courseTee) {
        this.courseTee = courseTee;
    }

    public Integer getRoundNumber() {
        return roundNumber;
    }

    public void setRoundNumber(Integer roundNumber) {
        this.roundNumber = roundNumber;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }
}